package com.example.myhealth.model;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.myhealth.data.FoodTask;
import com.example.myhealth.data.FoodsTask;

import java.util.ArrayList;
import java.util.List;

public class FoodService extends ViewModel {

    private static final String KEY = "65e8b024c3f1432381d1f0a6560bcec1";
    private static final String SECRET = "8ee216f7d9064696af2476153c555e83";
    private FoodsTask foodsTask;
    private FoodTask foodTask;
    private final MutableLiveData<List<Food>> filteredFoods;
    private MutableLiveData<List<MealFood>> selectedFoods;

    public FoodService() {
        filteredFoods = new MutableLiveData<>();
        selectedFoods = new MutableLiveData<>();
        selectedFoods.setValue(new ArrayList<>());
    }

    public void getFoods(String query, int pageNumber) {
        RequestBuilder builder = new RequestBuilder(KEY, SECRET);
        String apiUrl;
        {
            try {
                apiUrl = builder.buildFoodsSearchUrl(query, pageNumber);
                foodsTask = new FoodsTask(apiUrl);
                foodsTask.execute();
                foodsTask.setOnUpdateFoodsListener(() -> {
                    FoodContainer.getInstance().getFoodIds().forEach(id -> getFood(id));
//                   getFood(FoodContainer.getInstance().getFoodIds().get(0));
                });

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public void getFood(Long id) {
        RequestBuilder builder = new RequestBuilder(KEY, SECRET);
        String apiUrl;
        {
            try {
                apiUrl = builder.buildFoodGetUrl(id);
                foodTask = new FoodTask(apiUrl);
                foodTask.execute();
                foodTask.setOnPostExecuteListener(() -> {
                    this.filteredFoods.setValue(FoodContainer.getInstance().getFoods());
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public MutableLiveData<List<Food>> getFilteredFoods() {
        return filteredFoods;
    }

    public MutableLiveData<List<MealFood>> getSelectedFoods() {
        return selectedFoods;
    }

    public void setSelectedFoods(List<MealFood> selectedFoods) {
        this.selectedFoods.setValue(selectedFoods);
    }
}
