package com.example.myhealth.model;

import java.util.ArrayList;
import java.util.List;

public class FoodContainer {

    private static FoodContainer foodContainer = null;

    private List<Food> foods;

    private String max_results;

    private String page_number;

    private String total_results;

    private List<Long> foodIds;

    public List<Long> getFoodIds() {
        return foodIds;
    }

    public void setFoodIds(List<Long> foodIds) {
        this.foodIds = foodIds;
    }

    private FoodContainer() {
        this.foods = new ArrayList<>();
        this.foodIds = new ArrayList<>();
    }

    public static FoodContainer getInstance() {
        if (foodContainer == null)
            foodContainer = new FoodContainer();
        return foodContainer;
    }

    public String getMax_results() {
        return max_results;
    }

    public String getPage_number() {
        return page_number;
    }

    public String getTotal_results() {
        return total_results;
    }

    public void setFoods(List<Food> foods) {
        this.foods = foods;
    }

    public List<Food> getFoods() {
        return foods;
    }
}
