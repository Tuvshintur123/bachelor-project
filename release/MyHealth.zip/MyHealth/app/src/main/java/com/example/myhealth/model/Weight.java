package com.example.myhealth.model;

public class Weight {
    private double amount;

    public Weight(double amount) {
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
