package com.example.myhealth.model;


public class MealFood extends CompactFood{

    private Serving serving;

    public MealFood(Long id, String name, String type, String description, double servingAmount, long servingId) {
        super(id, name, type, description);
        this.serving = new Serving(servingId);
    }

    public MealFood(Long id, String name, String type, String description, String brandName, double servingAmount, long servingId) {
        super(id, name, type, description, brandName);
        this.serving = new Serving(servingId);
    }

    public MealFood(Long id, String name, String type, String description, String brandName, double servingAmount, Serving serving) {
        super(id, name, type, description, brandName);
        this.serving = serving;
    }

    public Serving getServing() {
        return serving;
    }

    public void setServing(Serving serving) {
        this.serving = serving;
    }
}
