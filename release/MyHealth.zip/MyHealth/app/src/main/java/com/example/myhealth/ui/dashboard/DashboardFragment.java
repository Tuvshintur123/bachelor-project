package com.example.myhealth.ui.dashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.example.myhealth.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class DashboardFragment extends Fragment {

    private DashboardViewModel dashboardViewModel;
    private CardView mCardViewBreakfast;
    private FloatingActionButton actionButton;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        BottomNavigationView view = getActivity().findViewById(R.id.nav_view);
        actionButton = getActivity().findViewById(R.id.action_button);
        actionButton.setVisibility(View.VISIBLE);
        if (view.getVisibility() == View.GONE)
            view.setVisibility(View.VISIBLE);
        dashboardViewModel =
                new ViewModelProvider(requireActivity()).get(DashboardViewModel.class);
        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);
//        final TextView textView = root.findViewById(R.id.txt_date);
//        dashboardViewModel.getText().observe(this, new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });

        mCardViewBreakfast = root.findViewById(R.id.cardView_breakfast);

        mCardViewBreakfast.setOnClickListener(v -> {
            Bundle bundle = new Bundle();
            bundle.putString("mealName", "Өглөөний цай");
            bundle.putString("mealDate", "2020-04-29");
            Navigation.findNavController(this.requireView()).navigate(R.id.action_navigation_dashboard_to_navigation_search, bundle);
        });
        return root;
    }
}